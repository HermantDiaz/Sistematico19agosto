
package Sistematico;
import java.util.Scanner;

public class Main {

/*
    HERMANT GABRIEL DIAZ GUADAMUZ 23-30008SU
    EXAMEN PRIMERO
*/
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        Datos_Cliente mostrar = new Datos_Cliente();
        
        mostrar.getNombre();
        mostrar.getApellido();
        mostrar.getDireccion();
        mostrar.MostrarDatos();
            
        
    }
    
}
