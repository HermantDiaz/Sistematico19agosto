package Sistematico;
import java.util.Scanner;

public class Datos_Cliente {
String nombre;
String Apellido;
String Direccion;

Scanner sc = new Scanner(System.in);

    public Datos_Cliente() {
        this.nombre = nombre;
        this.Apellido = Apellido;
        this.Direccion = Direccion;
        
    }

    public String getNombre() {
        System.out.println("¿Cual es tu nombre?");
        nombre = sc.next();
        return nombre;
    }
    
    public String getApellido() {
        System.out.println("¿Cual es tu apellido?");
        Apellido = sc.next();
        return Apellido;
    }

    public String getDireccion() {
        System.out.println("¿Cual es tu direccion?");
        Direccion = sc.next();
        return Direccion;
    }

    
public void MostrarDatos(){
System.out.println("");
System.out.println("DATOS DEL CLIENTE");
System.out.println("Nombre: " + nombre + " " + Apellido);
System.out.println("Direccion: " +Direccion );
}
    


    
}
