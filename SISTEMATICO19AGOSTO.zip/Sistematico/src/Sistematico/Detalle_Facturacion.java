
package Sistematico;

public class Detalle_Facturacion {
    Double Energia;
}
